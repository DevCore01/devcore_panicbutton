Config = {}

Config.Locale = 'en'

--Version 1.0 
--Script by devcore

Config.PoliceName = 'police'
Config.PanicButton = 38
Config.blipTime = 30