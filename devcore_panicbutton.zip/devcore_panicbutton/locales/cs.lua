Locales['cs'] = {
  ['panicbuttonblip'] = 'PANIC BUTTON',
}