Locales['en'] = {
  ['panicbuttonblip'] = 'PANIC BUTTON',
}